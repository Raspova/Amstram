import{a as t}from"../chunks/entry.BTpdAvnb.js";export{t as start};
