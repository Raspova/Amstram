import{a as t}from"../chunks/entry.DwUGzc7Z.js";export{t as start};
