import{a as t}from"../chunks/entry.xB_ENv57.js";export{t as start};
