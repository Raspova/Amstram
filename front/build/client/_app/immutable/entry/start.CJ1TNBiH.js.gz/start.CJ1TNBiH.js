import{a as t}from"../chunks/entry.Br8OwEhR.js";export{t as start};
