import{a as t}from"../chunks/entry.B9D0zW88.js";export{t as start};
