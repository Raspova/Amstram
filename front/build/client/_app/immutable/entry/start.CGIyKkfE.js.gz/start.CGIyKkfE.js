import{a as t}from"../chunks/entry.Dxldt9aA.js";export{t as start};
