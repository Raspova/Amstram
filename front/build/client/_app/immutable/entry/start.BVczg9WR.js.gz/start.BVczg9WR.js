import{a as t}from"../chunks/entry.Bt2gLXhC.js";export{t as start};
