import{a as t}from"../chunks/entry.Dx1_jLXn.js";export{t as start};
