import{a as t}from"../chunks/entry.Ci3JGWsG.js";export{t as start};
