import{a as t}from"../chunks/entry.76jRk6xm.js";export{t as start};
