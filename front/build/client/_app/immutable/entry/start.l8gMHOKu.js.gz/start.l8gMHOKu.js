import{a as t}from"../chunks/entry.B1Qad3sG.js";export{t as start};
