import{a as t}from"../chunks/entry.CsT-SpCU.js";export{t as start};
