import{a as t}from"../chunks/entry.BCff_Wrv.js";export{t as start};
