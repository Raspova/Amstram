import{a as t}from"../chunks/entry.DV3_0DnX.js";export{t as start};
