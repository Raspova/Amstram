import{a as t}from"../chunks/entry.Dd1GCq7g.js";export{t as start};
