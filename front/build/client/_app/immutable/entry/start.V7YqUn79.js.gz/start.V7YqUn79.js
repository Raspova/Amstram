import{a as t}from"../chunks/entry.BPltEkFX.js";export{t as start};
