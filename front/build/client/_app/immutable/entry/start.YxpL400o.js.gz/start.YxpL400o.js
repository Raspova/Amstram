import{a as t}from"../chunks/entry.-kxXnNai.js";export{t as start};
