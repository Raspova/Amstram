import{a as t}from"../chunks/entry.RkIKB5T9.js";export{t as start};
