import{a as t}from"../chunks/entry.BlyYFsjj.js";export{t as start};
