import{a as t}from"../chunks/entry.DshrzVKL.js";export{t as start};
