import{a as t}from"../chunks/entry.DSzJX19-.js";export{t as start};
