import{a as t}from"../chunks/entry.CqAVf3fg.js";export{t as start};
