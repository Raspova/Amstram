import{a as t}from"../chunks/entry.Bdag4QiK.js";export{t as start};
