import{a as t}from"../chunks/entry.CAyPiXvY.js";export{t as start};
