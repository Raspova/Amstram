import{a as t}from"../chunks/entry.CXniM8Ki.js";export{t as start};
