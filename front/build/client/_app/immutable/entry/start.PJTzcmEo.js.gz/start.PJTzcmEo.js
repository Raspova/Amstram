import{a as t}from"../chunks/entry.BCcV2tcX.js";export{t as start};
