import{a as t}from"../chunks/entry.BhbQEfb9.js";export{t as start};
