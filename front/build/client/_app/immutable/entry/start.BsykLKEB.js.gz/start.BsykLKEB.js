import{a as t}from"../chunks/entry.CAXbGHT5.js";export{t as start};
