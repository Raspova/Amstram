import{a as t}from"../chunks/entry.Dm7R9lco.js";export{t as start};
