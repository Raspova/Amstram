import{a as t}from"../chunks/entry.CyuQSVa8.js";export{t as start};
