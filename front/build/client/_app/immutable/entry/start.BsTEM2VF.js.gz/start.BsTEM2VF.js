import{a as t}from"../chunks/entry.BW_XWQaZ.js";export{t as start};
