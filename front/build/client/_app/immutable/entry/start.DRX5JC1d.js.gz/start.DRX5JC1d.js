import{a as t}from"../chunks/entry.Y-zcyDNK.js";export{t as start};
