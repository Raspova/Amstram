import{s}from"../chunks/scheduler._PVTacox.js";import{S as t,i as e}from"../chunks/index.Txt8zwyo.js";class l extends t{constructor(o){super(),e(this,o,null,null,s,{})}}export{l as component};
